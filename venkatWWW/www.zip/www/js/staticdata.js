var cats = {};
cats.lists = new Array();
cats.lists[0] = {};
cats.lists[0].id = 1;
cats.lists[0].title = "Health &amp; Wellness";
cats.lists[0].type = 0;
cats.lists[0].keyword = "Health &amp; Wellness";

cats.lists[1] = {};
cats.lists[1].id = 2;
cats.lists[1].title = "Religion &amp; Sprituality";
cats.lists[1].type = 0;
cats.lists[1].keyword = "Religion &amp; Sprituality";

cats.lists[2] = {};
cats.lists[2].id = 3;
cats.lists[2].title = "Rest &amp; Relaxation";
cats.lists[2].type = 0;
cats.lists[2].keyword = "Rest &amp; Relaxation";

cats.lists[3] = {};
cats.lists[3].id = 4;
cats.lists[3].title = "Socializing";
cats.lists[3].type = 0;
cats.lists[3].keyword = "Social";

cats.lists[4] = {};
cats.lists[4].id = 5;
cats.lists[4].title = "New Places";
cats.lists[4].type = 0;
cats.lists[4].keyword = "Travel";

cats.lists[5] = {};
cats.lists[5].id = 6;
cats.lists[5].title = "Kids &amp; Family";
cats.lists[5].type = 0;
cats.lists[5].keyword = "Kids &amp; Family";

cats.lists[6] = {};
cats.lists[6].id = 7;
cats.lists[6].title = "Holiday";
cats.lists[6].type = 0;
cats.lists[6].keyword = "Holiday";

cats.lists[7] = {};
cats.lists[7].id = 8;
cats.lists[7].title = "Sports";
cats.lists[7].type = 2;
cats.lists[7].keyword = "Sports";

cats.lists[8] = {};
cats.lists[8].id = 9;
cats.lists[8].title = "Adventures";
cats.lists[8].type = 3;
cats.lists[8].keyword = "Wildlife Trekking Paragliding";

cats.lists[9] = {};
cats.lists[9].id = 10;
cats.lists[9].title = "Exotic Vacation";
cats.lists[9].type = 3;
cats.lists[9].keyword = "Holiday Festivals Recreation";
