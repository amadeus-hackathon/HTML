/*
 * Aria Templates 1.4.12 - 07 Nov 2013
 *
 * Copyright 2009-2013 Amadeus s.a.s.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *    http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
/**
 * Beans to describe the parameters used in aria.pageEngine.pageProviders.BasePageProvider
 */
Aria.beanDefinitions({
    $package : "aria.pageEngine.pageProviders.BasePageProviderBeans",
    $description : "Definition of the beans used in aria.pageEngine.pageProviders.BasePageProvider",
    $namespaces : {
        "json" : "aria.core.JsonTypes"
    },
    $beans : {
        "Config" : {
            $type : "json:Object",
            $description : "Argument given to the constructor.",
            $properties : {
                "siteConfigLocation" : {
                    $type : "json:String",
                    $description : "Location of the file that contains the site configuration.",
                    $mandatory : true
                },
                "pageBaseLocation" : {
                    $type : "json:String",
                    $description : "Location of the folder that contains all the page definitions. Each file containing a page definition has to be called [pageId].json.",
                    $mandatory : true
                },
                "cache" : {
                    $type : "json:Boolean",
                    $description : "Whether to cache page definitions or to re-retrieve them from the speciefied url when navigating to them.",
                    $default : true
                },
                "homePageId" : {
                    $type : "json:String",
                    $description : "Id of the home page. It will be used as a default page.",
                    $mandatory : true
                }
            }
        }
    }
});
