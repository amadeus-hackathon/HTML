/*
 * Aria Templates 1.4.12 - 07 Nov 2013
 *
 * Copyright 2009-2013 Amadeus s.a.s.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *    http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
/**
 * Object which raises an event when an object is loaded.
 * @class aria.templates.ObjectLoading
 */
Aria.classDefinition({
    $classpath : 'aria.templates.ObjectLoading',
    $extends : 'aria.templates.PublicWrapper',
    $implements : ['aria.templates.IObjectLoading'],
    $constructor : function () {
        this.$PublicWrapper.constructor.call(this);
    },
    $prototype : {
        $publicInterfaceName : 'aria.templates.IObjectLoading',

        /**
         * Notify listeners that the object is loaded.
         * @param {Object} object reference to the object just loaded.
         */
        notifyObjectLoaded : function (object) {
            this.$raiseEvent({
                name : "objectLoaded",
                object : object
            });
        }
    }
});